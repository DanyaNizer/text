$(document).ready(function(){
  $('.slider__main').slick({
  infinite: true,
  speed: 500,
  fade: true,
  cssEase: 'linear',
  autoplay: true,
  autoplaySpeed: 8000,
  });
});